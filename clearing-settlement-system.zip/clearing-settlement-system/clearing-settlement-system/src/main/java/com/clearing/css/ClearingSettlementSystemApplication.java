package com.clearing.css;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClearingSettlementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClearingSettlementSystemApplication.class, args);
	}

}