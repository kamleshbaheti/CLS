package com.clearing.css.config;

import com.clearing.css.model.AppUser;
import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.model.enums.UserRole;
import com.clearing.css.repository.TradeRepository;
import com.clearing.css.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner initDatabase(UserRepository repo, TradeRepository tradeRepo, PasswordEncoder encoder) {
        return args -> {
            // 1. Seed Users (Roles)
            if (repo.count() == 0) {
                repo.save(new AppUser("admin", encoder.encode("password"), "admin@css.com", UserRole.ADMIN));
                repo.save(new AppUser("clear", encoder.encode("password"), "clear@css.com", UserRole.CLEARING_OFFICER));
                repo.save(new AppUser("settle", encoder.encode("password"), "settle@css.com", UserRole.SETTLEMENT_OFFICER));
            }

            // 2. Seed Sample Trades using the new Two-Legged Model
//            if (tradeRepo.count() == 0) {
//
//                // CASE 1: Open Seller Offer (Waiting for Buyer)
//                Trade t1 = new Trade();
//                t1.setInstrument("REL-IND");
//                t1.setTradeDate(LocalDate.now());
//                t1.setSellerId(2001L);
//                t1.setSellerQuantity(100);
//                t1.setSellerPrice(new BigDecimal("2450.00"));
//                t1.setStatus(TradeStatus.UNMATCHED);
//                tradeRepo.save(t1);
//
//                // CASE 2: Perfectly Matched Trade (Ready for Clearing Officer)
//                // (Seller Price * Qty) == (Buyer Price * Qty) -> 200 * 50 = 10,000
//                Trade t2 = new Trade();
//                t2.setInstrument("TATA-MOT");
//                t2.setTradeDate(LocalDate.now());
//                // Seller side
//                t2.setSellerId(2002L);
//                t2.setSellerQuantity(200);
//                t2.setSellerPrice(new BigDecimal("50.00"));
//                // Buyer side
//                t2.setBuyerId(3002L);
//                t2.setBuyerQuantity(200);
//                t2.setBuyerPrice(new BigDecimal("50.00"));
//
//                t2.setStatus(TradeStatus.MATCHED);
//                tradeRepo.save(t2);
//
//                // CASE 3: Trade with Discrepancy (Unmatched due to Price difference)
//                Trade t3 = new Trade();
//                t3.setInstrument("INFY-GBL");
//                t3.setTradeDate(LocalDate.now());
//                // Seller side
//                t3.setSellerId(2003L);
//                t3.setSellerQuantity(10);
//                t3.setSellerPrice(new BigDecimal("1500.00"));
//                // Buyer side (Reports a different price)
//                t3.setBuyerId(3003L);
//                t3.setBuyerQuantity(10);
//                t3.setBuyerPrice(new BigDecimal("1495.00"));
//
//                t3.setStatus(TradeStatus.UNMATCHED);
//                tradeRepo.save(t3);
//            }
        };
    }
}