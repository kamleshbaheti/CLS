package com.clearing.css.config;

import com.clearing.css.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig {

    private final PasswordEncoder passwordEncoder;

    public SecurityConfig(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(UserService userService) {
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService(userService);
        auth.setPasswordEncoder(passwordEncoder);
        return auth;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, UserService userService) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login", "/logout", "/css/**", "/logout-success").permitAll()
                        .requestMatchers("/admin/**").hasAuthority("ADMIN")
                        .requestMatchers("/trades/**").hasAnyAuthority("ADMIN", "CLEARING_OFFICER", "SETTLEMENT_OFFICER")
                        .requestMatchers("/clearing/**").hasAnyAuthority("CLEARING_OFFICER", "ADMIN")
                        .requestMatchers("/settlements/**").hasAnyAuthority("SETTLEMENT_OFFICER", "ADMIN")
                        .requestMatchers("/reconciliation/**").hasAnyAuthority("CLEARING_OFFICER", "ADMIN")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .successHandler((request, response, authentication) -> {
                            var authorities = authentication.getAuthorities();
                            String redirectUrl = "/login?error";
                            for (var auth : authorities) {
                                if (auth.getAuthority().equals("ADMIN")) { redirectUrl = "/admin/users"; break; }
                                else if (auth.getAuthority().equals("CLEARING_OFFICER")) { redirectUrl = "/clearing/process-trades"; break; }
                                else if (auth.getAuthority().equals("SETTLEMENT_OFFICER")) { redirectUrl = "/settlements/pending-trades"; break; }
                            }
                            response.sendRedirect(redirectUrl);
                        })
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login?logout")
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                        .permitAll()
                );

        return http.build();
    }
}