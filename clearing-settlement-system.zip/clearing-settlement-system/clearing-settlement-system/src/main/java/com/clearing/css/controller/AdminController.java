package com.clearing.css.controller;

import com.clearing.css.model.AppUser;
import com.clearing.css.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;

    public AdminController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public String listUsers(Model model) {
//        Fetch data from DB using a Service/Repository & You "hand" the data to the HTML using model att.
        model.addAttribute("users", userService.findAllUsers());
        model.addAttribute("newUser", new AppUser()); // For the create form
        return "admin/users";
    }

    @PostMapping("/users/create")
    public String createUser(@Valid @ModelAttribute("newUser") AppUser user, BindingResult result, Model model) {
        // Check if username already exists (Custom Validation)
        if (userService.existsByUsername(user.getUsername())) {
            result.rejectValue("username", "error.user", "This username is already taken");
        }

        if (result.hasErrors()) {
            // Re-populate the table list so the page doesn't look empty
            model.addAttribute("users", userService.findAllUsers());
            return "admin/users"; // Return to the form view instead of redirecting
        }
        userService.saveUser(user);
        return "redirect:/admin/users";
    }

    // Add this to AdminController.java
    @PostMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/admin/users";
    }
}