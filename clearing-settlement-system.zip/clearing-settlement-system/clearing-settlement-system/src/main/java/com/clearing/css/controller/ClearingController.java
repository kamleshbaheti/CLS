package com.clearing.css.controller;

import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.service.ClearingService;
import com.clearing.css.service.TradeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/clearing")
public class ClearingController {

    private final ClearingService clearingService;
    private final TradeService tradeService;

    public ClearingController(ClearingService clearingService, TradeService tradeService) {
        this.clearingService = clearingService;
        this.tradeService = tradeService;
    }

    @GetMapping("/summary")
    public String viewClearing(Model model) {
        // Calling it to refresh page contents.
        clearingService.runNettingProcess();

        model.addAttribute("clearingData", clearingService.getClearingSummary());

//        List<Trade> clearedTrades = new ArrayList<>();
//        for (Trade t : tradeService.getAllTrades()) {
//            if (t.getStatus() != null && t.getStatus() != TradeStatus.UNMATCHED && t.getStatus() != TradeStatus.MATCHED) {
//                clearedTrades.add(t);
//            }
//        }

        List<Trade> clearedTrades = tradeService.getAllTrades().stream()
                .filter(t -> t.getStatus() != null && t.getStatus() != TradeStatus.UNMATCHED && t.getStatus() != TradeStatus.MATCHED)
                .toList();

        model.addAttribute("clearedTrades", clearedTrades);
        return "clearing/summary";
    }

    @GetMapping("/process-trades")
    public String showTradesToClear(Model model) {
        List<Trade> matchedTrades = tradeService.getAllTrades().stream()
                .filter(t -> t.getStatus() != null && t.getStatus() == TradeStatus.MATCHED)
                .toList();
        model.addAttribute("trades", matchedTrades);
        return "clearing/process";
    }

    @PostMapping("/clear/{id}")
    public String clearSpecificTrade(@PathVariable Long id) {
        clearingService.clearTrade(id);
        return "redirect:/clearing/process-trades";
    }
}