package com.clearing.css.controller;

import com.clearing.css.model.enums.ReconciliationStatus;
import com.clearing.css.service.ReconciliationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reconciliation")
public class ReconciliationController {

    private final ReconciliationService reconciliationService;

    public ReconciliationController(ReconciliationService reconciliationService) {
        this.reconciliationService = reconciliationService;
    }

    @GetMapping("/list")
    public String viewReconciliation(Model model) {
        // Show trades waiting to be reconciled
        model.addAttribute("pendingTrades", reconciliationService.getPendingReconciliationTrades());
        // Show history of reconciled trades
        model.addAttribute("reconciliations", reconciliationService.getAllReconciliations());
        return "reconciliation/list";
    }

    @PostMapping("/process/{id}")
    public String processReconciliation(@PathVariable Long id, @RequestParam ReconciliationStatus status) {
        reconciliationService.reconcileTrade(id, status);
        return "redirect:/reconciliation/list";
    }
}