package com.clearing.css.controller;

import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.service.SettlementService;
import com.clearing.css.service.TradeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/settlements")
public class SettlementController {

    private final SettlementService settlementService;

    public SettlementController(SettlementService settlementService) {
        this.settlementService = settlementService;
    }

    @GetMapping("/list")
    public String listSettlements(Model model) {
        model.addAttribute("settlements", settlementService.getAllSettlements());
        return "settlements/list";
    }

    // Trigger generation of settlement instructions (T+2)
    @PostMapping("/generate")
    public String generateInstructions() {
        settlementService.generateSettlementInstructions();
        return "redirect:/settlements/list";
    }

    // Mark a specific settlement as COMPLETED
    @PostMapping("/{id}/complete")
    public String completeSettlement(@PathVariable Long id) {
        settlementService.completeSettlement(id);
        return "redirect:/settlements/list";
    }

    @GetMapping("/pending-trades")
    public String showTradesToSettle(Model model) {
        // 1. Get all trades that are in CLEARED status
        List<Trade> clearedTrades = TradeService.getAllTrades().stream() // Assuming tradeService is available
                .filter(t -> t.getStatus() == TradeStatus.CLEARED)
                .toList();

        // 2. Get all existing settlements and extract the trade IDs into a Set for fast lookups
        Set<Long> settledTradeIds = settlementService.getAllSettlements().stream()
                .map(settlement -> settlement.getTrade().getTradeId())
                .collect(Collectors.toSet());

        // 3. Pass both lists to the model
        model.addAttribute("trades", clearedTrades);
        model.addAttribute("settledTradeIds", settledTradeIds); // This is the new, important part

        return "settlements/process-view";
    }

    @PostMapping("/initiate/{id}")
    public String initiateSettlement(@PathVariable Long id) {
        settlementService.createSettlementForTrade(id);
        return "redirect:/settlements/pending-trades";
    }
}