package com.clearing.css.controller;

import com.clearing.css.model.Trade;
import com.clearing.css.service.TradeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/trades")
public class TradeController {

    private final TradeService tradeService;

    public TradeController(TradeService tradeService) {
        this.tradeService = tradeService;
    }

    @GetMapping("/list")
    public String listTrades(Model model) {
        List<Trade> all = tradeService.getAllTrades();
        // Seller Table (Unmatched/Open offers)
        model.addAttribute("openOffers", all.stream().filter(t -> t.getBuyerId() == null).toList());
        // Buyer/Matched Table (Trades with both sides entered)
        model.addAttribute("processedTrades", all.stream().filter(t -> t.getBuyerId() != null).toList());
        return "trades/list";
    }

    @PostMapping("/save-seller")
    public String saveSeller(@ModelAttribute Trade trade) {
        tradeService.saveSellerOffer(trade);
        return "redirect:/trades/list";
    }

    @GetMapping("/fill-buyer/{id}")
    public String fillBuyerForm(@PathVariable Long id, Model model) {
        model.addAttribute("trade", tradeService.getTradeById(id));
        return "trades/fill-buyer";
    }

    @PostMapping("/match-buyer")
    public String matchBuyer(@RequestParam Long tradeId, @RequestParam Long buyerId,
                             @RequestParam Integer buyerQuantity, @RequestParam BigDecimal buyerPrice) {
        tradeService.updateBuyerInstruction(tradeId, buyerId, buyerQuantity, buyerPrice);
        return "redirect:/trades/list";
    }
}