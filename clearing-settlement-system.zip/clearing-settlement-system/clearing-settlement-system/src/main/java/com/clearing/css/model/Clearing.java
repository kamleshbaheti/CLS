package com.clearing.css.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Clearing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long clearingId;

    private Long participantId;
    private BigDecimal netAmount; // Positive = Receivable, Negative = Payable
    private Integer netQuantity;  // Net securities position
    private Long tradeId;

    // Getters and Setters
    public Clearing(Long participantId, BigDecimal netAmount, Integer netQuantity, Long tradeId) {
        this.participantId = participantId;
        this.netAmount = netAmount;
        this.netQuantity = netQuantity;
        this.tradeId = tradeId;
    }
    public Clearing() {}

    public Long getClearingId() {
        return clearingId;
    }

    public void setClearingId(Long clearingId) {
        this.clearingId = clearingId;
    }

    public Long getParticipantId() {
        return participantId;
    }

    public void setParticipantId(Long participantId) {
        this.participantId = participantId;
    }

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(BigDecimal netAmount) {
        this.netAmount = netAmount;
    }

    public Integer getNetQuantity() {
        return netQuantity;
    }

    public void setNetQuantity(Integer netQuantity) {
        this.netQuantity = netQuantity;
    }

    public Long getTradeId() {
        return tradeId;
    }

    public void setTradeId(Long tradeId) {
        this.tradeId = tradeId;
    }
}