package com.clearing.css.model;

import com.clearing.css.model.enums.SettlementStatus;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Settlement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long settlementId;

    @OneToOne
    @JoinColumn(name = "trade_id")
    private Trade trade;

    private LocalDate settlementDate;

    @Enumerated(EnumType.STRING)
    private SettlementStatus status;

    // Getters and Setters

    public Long getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(Long settlementId) {
        this.settlementId = settlementId;
    }

    public Trade getTrade() {
        return trade;
    }

    public void setTrade(Trade trade) {
        this.trade = trade;
    }

    public LocalDate getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(LocalDate settlementDate) {
        this.settlementDate = settlementDate;
    }

    public SettlementStatus getStatus() {
        return status;
    }

    public void setStatus(SettlementStatus status) {
        this.status = status;
    }
}