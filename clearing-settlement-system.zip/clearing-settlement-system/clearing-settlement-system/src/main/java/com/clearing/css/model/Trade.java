package com.clearing.css.model;

import com.clearing.css.model.enums.TradeStatus;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
public class Trade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tradeId;

    private String instrument;
    private LocalDate tradeDate;

    // Seller Perspective
    private Long sellerId;
    private Integer sellerQuantity;
    private BigDecimal sellerPrice;

    // Buyer Perspective
    private Long buyerId;
    private Integer buyerQuantity;
    private BigDecimal buyerPrice;

    @Enumerated(EnumType.STRING)
    private TradeStatus status = TradeStatus.UNMATCHED;

    public Long getTradeId() { return tradeId; }
    public void setTradeId(Long tradeId) { this.tradeId = tradeId; }
    public String getInstrument() { return instrument; }
    public void setInstrument(String instrument) { this.instrument = instrument; }
    public LocalDate getTradeDate() { return tradeDate; }
    public void setTradeDate(LocalDate tradeDate) { this.tradeDate = tradeDate; }

    public Long getSellerId() { return sellerId; }
    public void setSellerId(Long sellerId) { this.sellerId = sellerId; }
    public Integer getSellerQuantity() { return sellerQuantity; }
    public void setSellerQuantity(Integer sellerQuantity) { this.sellerQuantity = sellerQuantity; }
    public BigDecimal getSellerPrice() { return sellerPrice; }
    public void setSellerPrice(BigDecimal sellerPrice) { this.sellerPrice = sellerPrice; }

    public Long getBuyerId() { return buyerId; }
    public void setBuyerId(Long buyerId) { this.buyerId = buyerId; }
    public Integer getBuyerQuantity() { return buyerQuantity; }
    public void setBuyerQuantity(Integer buyerQuantity) { this.buyerQuantity = buyerQuantity; }
    public BigDecimal getBuyerPrice() { return buyerPrice; }
    public void setBuyerPrice(BigDecimal buyerPrice) { this.buyerPrice = buyerPrice; }

    public TradeStatus getStatus() { return status; }
    public void setStatus(TradeStatus status) { this.status = status; }
}