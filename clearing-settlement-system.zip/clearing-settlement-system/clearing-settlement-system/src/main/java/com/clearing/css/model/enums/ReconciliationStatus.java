package com.clearing.css.model.enums;

public enum ReconciliationStatus {
    VALIDATED, DISCREPANCY
}
