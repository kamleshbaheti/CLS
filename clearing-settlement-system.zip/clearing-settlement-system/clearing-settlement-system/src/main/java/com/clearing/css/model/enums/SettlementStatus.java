package com.clearing.css.model.enums;

public enum SettlementStatus {
    PENDING, COMPLETED
}
