package com.clearing.css.model.enums;

public enum TradeStatus {
    MATCHED, UNMATCHED, CLEARED, SETTLED, RECONCILED
}
