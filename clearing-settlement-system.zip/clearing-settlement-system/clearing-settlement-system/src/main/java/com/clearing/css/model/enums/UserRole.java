package com.clearing.css.model.enums;

public enum UserRole {
    ADMIN,
    CLEARING_OFFICER,
    SETTLEMENT_OFFICER
}