package com.clearing.css.repository;

import com.clearing.css.model.Clearing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClearingRepository extends JpaRepository<Clearing, Long> {
    void deleteByParticipantId(Long participantId);
}