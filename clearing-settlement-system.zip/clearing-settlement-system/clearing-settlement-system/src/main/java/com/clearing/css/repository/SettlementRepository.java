package com.clearing.css.repository;

import com.clearing.css.model.Settlement;
import com.clearing.css.model.enums.SettlementStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SettlementRepository extends JpaRepository<Settlement, Long> {
    List<Settlement> findByStatus(SettlementStatus status);
}