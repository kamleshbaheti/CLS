package com.clearing.css.repository;

import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TradeRepository extends JpaRepository<Trade, Long> {
    List<Trade> findByStatus(TradeStatus status);
}