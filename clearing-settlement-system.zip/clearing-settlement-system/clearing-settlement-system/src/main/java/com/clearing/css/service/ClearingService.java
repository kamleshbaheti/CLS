package com.clearing.css.service;

import com.clearing.css.model.Clearing;
import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.repository.ClearingRepository;
import com.clearing.css.repository.TradeRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

@Service
public class ClearingService {

    private final TradeRepository tradeRepository;
    private final ClearingRepository clearingRepository;

    public ClearingService(TradeRepository tradeRepository, ClearingRepository clearingRepository) {
        this.tradeRepository = tradeRepository;
        this.clearingRepository = clearingRepository;
    }

    public void runNettingProcess() {
        // Wipe previous calculations for a fresh run
        clearingRepository.deleteAll();

        // Fetching all trades from db
        List<Trade> trades = tradeRepository.findAll();

        for (Trade t : trades) {
            // Only process trades that are ready Matched
            if (t.getStatus() != TradeStatus.UNMATCHED) {

                // Calculate Total Financial Value: Price * Quantity
                BigDecimal tradeValue = t.getSellerPrice().multiply(BigDecimal.valueOf(t.getBuyerQuantity()));

                // Seller receives cash (Positive) and delivers shares (Negative Quantity)
                Clearing sellerLeg = new Clearing();
                sellerLeg.setParticipantId(t.getSellerId());
                sellerLeg.setNetAmount(tradeValue);
                sellerLeg.setNetQuantity(-t.getBuyerQuantity());
                sellerLeg.setTradeId(t.getTradeId());
                clearingRepository.save(sellerLeg);

                // Buyer pays cash (Negative) and receives shares (Positive Quantity)
                Clearing buyerLeg = new Clearing();
                buyerLeg.setParticipantId(t.getBuyerId());
                buyerLeg.setNetAmount(tradeValue.negate());
                buyerLeg.setNetQuantity(t.getBuyerQuantity());
                buyerLeg.setTradeId(t.getTradeId());
                clearingRepository.save(buyerLeg);
            }
        }
    }

    public List<Clearing> getClearingSummary() {
        return clearingRepository.findAll();
    }

    public void clearTrade(Long tradeId) {
        Trade trade = tradeRepository.findById(tradeId)
                .orElseThrow(() -> new RuntimeException("Trade not found"));

        if (trade.getStatus() == TradeStatus.MATCHED) {

            trade.setStatus(TradeStatus.CLEARED);
            tradeRepository.save(trade);

            // Use the seller total as the verified value for clearing records
            BigDecimal tradeValue = trade.getSellerPrice().multiply(BigDecimal.valueOf(trade.getBuyerQuantity()));

            // Update DB with individual clearing entries for audit
            clearingRepository.save(new Clearing(trade.getBuyerId(), tradeValue.negate(), trade.getBuyerQuantity(), tradeId));
            clearingRepository.save(new Clearing(trade.getSellerId(), tradeValue, -trade.getBuyerQuantity(), tradeId));

            // Re-run netting to refresh the summary page
            runNettingProcess();
        }
    }
}