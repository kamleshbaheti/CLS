package com.clearing.css.service;

import com.clearing.css.model.Reconciliation;
import com.clearing.css.model.Settlement;
import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.ReconciliationStatus;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.repository.ReconciliationRepository;
import com.clearing.css.repository.SettlementRepository;
import com.clearing.css.repository.TradeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReconciliationService {

    private final ReconciliationRepository reconciliationRepository;
    private final SettlementRepository settlementRepository;
    private final TradeRepository tradeRepository;

    public ReconciliationService(ReconciliationRepository reconciliationRepository,
                                 SettlementRepository settlementRepository,
                                 TradeRepository tradeRepository) {
        this.reconciliationRepository = reconciliationRepository;
        this.settlementRepository = settlementRepository;
        this.tradeRepository = tradeRepository;
    }

    // 1. Get trades that have been settled but NOT yet reconciled
    public List<Trade> getPendingReconciliationTrades() {
        List<Long> reconciledTradeIds = reconciliationRepository.findAll()
                .stream().map(r -> r.getTrade().getTradeId()).toList();

        return settlementRepository.findAll().stream()
                .map(Settlement::getTrade)
                .filter(trade -> !reconciledTradeIds.contains(trade.getTradeId()))
                .collect(Collectors.toList());
    }

    // 2. Process a single trade reconciliation
    public void reconcileTrade(Long tradeId, ReconciliationStatus status) {
        Trade trade = tradeRepository.findById(tradeId).orElseThrow();

        Reconciliation rec = new Reconciliation();
        rec.setTrade(trade);
        rec.setStatus(status);

        if (status == ReconciliationStatus.VALIDATED) {
            rec.setNotes("Verified: Trade and Settlement data align perfectly.");
        } else {
            rec.setNotes("Discrepancy flagged by officer for manual investigation.");
        }

        reconciliationRepository.save(rec);

        trade.setStatus(TradeStatus.RECONCILED);
        tradeRepository.save(trade);

    }

    public List<Reconciliation> getAllReconciliations() {
        return reconciliationRepository.findAll();
    }
}