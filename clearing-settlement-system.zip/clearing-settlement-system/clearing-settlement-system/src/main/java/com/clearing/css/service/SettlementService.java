package com.clearing.css.service;

import com.clearing.css.model.Settlement;
import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.SettlementStatus;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.repository.SettlementRepository;
import com.clearing.css.repository.TradeRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class SettlementService {
    private final SettlementRepository settlementRepository;
    private final TradeRepository tradeRepository;

    public SettlementService(SettlementRepository sr, TradeRepository tr) {
        this.settlementRepository = sr;
        this.tradeRepository = tr;
    }

    public void generateSettlementInstructions() {
        List<Trade> trades = tradeRepository.findAll();

        for(Trade t : trades) {
            // Only settle trades that have been MATCHED
            if(t.getStatus() == TradeStatus.MATCHED) {
                boolean exists = settlementRepository.findAll().stream()
                        .anyMatch(s -> s.getTrade().getTradeId().equals(t.getTradeId()));

                if(!exists) {
                    Settlement s = new Settlement();
                    s.setTrade(t);
                    s.setSettlementDate(LocalDate.now().plusDays(2)); // T+2 standard
                    s.setStatus(SettlementStatus.PENDING);
                    settlementRepository.save(s);
                }
            }
        }
    }

    public void createSettlementForTrade(Long tradeId) {
        Trade trade = tradeRepository.findById(tradeId).orElseThrow();
        if (trade.getStatus() == TradeStatus.CLEARED) {
            Settlement s = new Settlement();
            s.setTrade(trade);
            s.setSettlementDate(LocalDate.now().plusDays(2)); // Priority Settlement
            s.setStatus(SettlementStatus.PENDING);
            settlementRepository.save(s);
        }
    }

    public void completeSettlement(Long settlementId) {
        Settlement s = settlementRepository.findById(settlementId).orElseThrow();
        s.setStatus(SettlementStatus.COMPLETED);

        Trade t = s.getTrade();

        if (t != null) {
            // 4. Update the trade status to SETTLED (Ensure SETTLED exists in your TradeStatus enum)
            t.setStatus(TradeStatus.SETTLED);

            // 5. Save the trade back to the database
            tradeRepository.save(t);
        }

        settlementRepository.save(s);
    }

    public List<Settlement> getAllSettlements() {
        return settlementRepository.findAll();
    }
}