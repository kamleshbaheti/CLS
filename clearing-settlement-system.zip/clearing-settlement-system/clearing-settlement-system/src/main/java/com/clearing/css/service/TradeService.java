package com.clearing.css.service;

import com.clearing.css.model.Trade;
import com.clearing.css.model.enums.TradeStatus;
import com.clearing.css.repository.TradeRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class TradeService {
    private static TradeRepository tradeRepository = null;

    public TradeService(TradeRepository tradeRepository) {
        this.tradeRepository = tradeRepository;
    }

    public static List<Trade> getAllTrades() {
        return tradeRepository.findAll();
    }

    public Trade getTradeById(Long id) {
        return tradeRepository.findById(id).orElseThrow();
    }

    // 1. Seller creates the initial record
    public void saveSellerOffer(Trade trade) {
        trade.setTradeDate(LocalDate.now());
        trade.setStatus(TradeStatus.UNMATCHED);
        tradeRepository.save(trade);
    }

    // 2. Matching Engine Logic
    public void updateBuyerInstruction(Long tradeId, Long buyerId, Integer qty, BigDecimal price) {
        Trade trade = tradeRepository.findById(tradeId).orElseThrow();

        trade.setBuyerId(buyerId);
        trade.setBuyerQuantity(qty);
        trade.setBuyerPrice(price);

        // Price must match AND Buyer Qty must be <= Seller Qty
        boolean isPriceEqual = trade.getSellerPrice().compareTo(price) == 0;
        boolean isQtyAvailable = trade.getSellerQuantity() >= qty;

        if (isPriceEqual && isQtyAvailable) {
            trade.setStatus(TradeStatus.MATCHED);
        } else {
            trade.setStatus(TradeStatus.UNMATCHED);
        }

        tradeRepository.save(trade);
    }
}