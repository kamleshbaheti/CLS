package com.clearing.css;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClearingSettlementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
